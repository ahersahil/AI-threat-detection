# 🛡️ SentinelLab & AI Threat Detector
### Network Penetration Testing, Wireshark Protocol Analysis & AI Threat Detection Lab

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-VirtualBox%20%7C%20Kali%20Linux%20%7C%20Windows-00f3ff.svg)](#)
[![Standards](https://img.shields.io/badge/Framework-NIST%20SP%20800--115%20%7C%20PTES-00ff88.svg)](#)
[![Security Level](https://img.shields.io/badge/Severity-CRITICAL%20(CVSS%209.8)-ff2a5f.svg)](#)

A comprehensive, hands-on cybersecurity practice project demonstrating end-to-end network penetration testing, live packet traffic analysis, and machine-learning/heuristic threat detection within an isolated virtual lab environment.

---

## 📑 Table of Contents
1. [Project Overview](#-project-overview)
2. [Lab Topology & Architecture](#-lab-topology--architecture)
3. [Key Capabilities & Features](#-key-capabilities--features)
4. [Interactive Security Dashboard](#-interactive-security-dashboard)
5. [CLI & Automation Tooling](#-cli--automation-tooling)
6. [Lab Testing Methodology](#-lab-testing-methodology)
7. [Documented Vulnerabilities (CVE Matrix)](#-documented-vulnerabilities-cve-matrix)
8. [Defensive Countermeasures & Hardening](#-defensive-countermeasures--hardening)
9. [Project File Structure](#-project-file-structure)
10. [Quick Start Guide](#-quick-start-guide)

---

## 🎯 Project Overview

This project was built to simulate realistic enterprise network assessment workflows in a controlled sandbox environment using **Kali Linux** and **Oracle VirtualBox**. It covers:

* **Network Reconnaissance & Host Discovery:** Using **Nmap** (`-sS`, `-sV`, `-O`, `-sC`) to enumerate active hosts, identify running daemons, and fingerprint target operating systems.
* **Network Traffic Inspection & Protocol Dissection:** Capturing packets with **Wireshark** to decode TCP 3-way handshakes and isolate unencrypted credentials (Telnet/FTP).
* **Vulnerability Assessment & Exploitation:** Verifying known CVEs (e.g. `vsftpd 2.3.4` backdoor root shell, `DistCC` remote code execution) using the **Metasploit Framework**.
* **AI & Heuristic Threat Detection:** Classifying packet streams, computing **Shannon Entropy** to identify obfuscated shellcode, and generating automated firewall (`iptables`) and IDS (`Snort`) defensive rules.
* **Professional Reporting:** Generating executive and technical vulnerability assessment reports aligned with **NIST SP 800-115** and **CVSS v3.1** standards.

---

## 🏗️ Lab Topology & Architecture

To ensure safety and isolation, all testing is confined to a dedicated **Host-Only Virtual Subnet** (`192.168.56.0/24`):

```
+-----------------------------------------------------------------------+
|                    VirtualBox Hypervisor (Isolated Subnet)            |
|                                                                       |
|   +--------------------------+        +---------------------------+   |
|   |   Kali Linux (Attacker)  |        |  Metasploitable2 (Target) |   |
|   |   IP: 192.168.56.101     |        |  IP: 192.168.56.102       |   |
|   |                          |        |                           |   |
|   |   * Nmap Port Scanner    |        |   * vsftpd 2.3.4 (Port 21)|   |
|   |   * Wireshark Dissector  | =====> |   * Telnet (Port 23)      |   |
|   |   * Metasploit Framework |        |   * DistCC (Port 3632)    |   |
|   |   * AI Threat Engine     |        |   * Samba smbd (Port 139) |   |
|   +--------------------------+        +---------------------------+   |
|                \                                    /                 |
|                 \                                  /                  |
|              VirtualBox Host-Only Adapter (192.168.56.1)              |
+-----------------------------------------------------------------------+
```

---

## ✨ Key Capabilities & Features

### 1. Active Reconnaissance & Port Enumeration
* Probes common services (FTP, SSH, Telnet, HTTP, SMB, DistCC, MySQL).
* Grabs service banners and measures TCP handshake latency.
* Correlates discovered open ports with known CVE records in real-time.

### 2. Wireshark PCAP Dissector & Packet Inspection
* Reconstructs TCP streams to detect plain-text authentication credentials (`USER` / `PASS`).
* Dissects raw packet bytes into hex dumps and ASCII representations.
* Computes Shannon Entropy per payload to spot obfuscated shellcode or binary payloads.

### 3. AI & Heuristic Threat Detection Engine
* **Statistical Anomaly Scoring:** Evaluates packet entropy spikes (>3.7 bits/byte).
* **Exploit Signature Matching:** Detects malicious triggers (vsftpd `:)` backdoor, DistCC RCE headers, SQLi, Path Traversal).
* **Automated Defense Generation:** Instantly outputs targeted `iptables` drop rules and `Snort` alert signatures.

### 4. Interactive Metasploit & CVE Matrix
* Comprehensive breakdown of lab-verified vulnerabilities with CVSS v3.1 vectors, exploit modules, and remediation steps.

---

## 💻 Interactive Security Dashboard

The project includes a built-in, cyber-themed Security Operations Center (SOC) web application:

To launch the dashboard locally:
```bash
npm start
# Server listens at: http://localhost:3000
```

### Dashboard Tabs:
1. **SOC Overview:** Live telemetry, environment topology, overall threat level, and gauge meters.
2. **Nmap & Recon Scanner:** Interactive TCP port probe with customizable scan profiles.
3. **Wireshark PCAP Inspector:** Real-time packet table with protocol filters and payload hex viewer.
4. **AI Threat Detector:** Automated classification with confidence scores and recommended mitigations.
5. **Metasploit CVE Matrix:** Detailed CVE cards with exact `msfconsole` module syntax.
6. **Pentest Report Generator:** Exportable Markdown/HTML penetration testing report.

---

## 🛠️ CLI & Automation Tooling

Cross-platform security automation scripts located in `scripts/`:

| Script | Language | Purpose |
| :--- | :--- | :--- |
| `scripts/python/nmap_recon.py` | Python 3 | Multi-stage automated Nmap scanner with JSON report generation |
| `scripts/python/pcap_analyzer.py` | Python 3 | Dissects PCAP files, calculates entropy, flags credential leaks |
| `scripts/python/ai_threat_classifier.py`| Python 3 | Standalone heuristic threat classification engine |
| `scripts/python/banner_grabber.py` | Python 3 | Multi-threaded pure-socket service banner grabber (zero dependencies) |
| `scripts/bash/setup_lab.sh` | Bash | Automates Kali Linux package verification and lab interface detection |
| `scripts/bash/capture_traffic.sh` | Bash | Automates tcpdump background packet capture on target interfaces |

---

## 🔍 Documented Vulnerabilities (CVE Matrix)

| Port | Service | Vulnerability | Severity | CVSS v3.1 | Exploit Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **21/TCP** | vsftpd 2.3.4 | Backdoor Command Execution (`CVE-2011-2523`) | **CRITICAL** | **9.8** | Root shell verified on port 6200 |
| **139/TCP**| Samba 3.0.20 | Usermap Script Command Execution (`CVE-2007-2447`) | **CRITICAL** | **9.8** | Unauthenticated root execution |
| **3632/TCP**| DistCC 3.1.1 | Distributed Compiler RCE (`CVE-2004-2687`) | **HIGH** | **8.8** | Daemon shell verified |
| **23/TCP** | Telnet | Cleartext Credential Exposure (`CWE-319`) | **HIGH** | **7.5** | Credentials sniffed in Wireshark |
| **22/TCP** | OpenSSH 4.7p1 | Predictable Debian PRNG Keys (`CVE-2008-0166`) | **HIGH** | **7.5** | Weak keys enumerated |

---

## 🛡️ Defensive Countermeasures & Hardening

1. **Service Decommissioning & Patching:**
   - Terminate obsolete daemons: `sudo apt-get remove vsftpd distcc`.
   - Update services to patched upstream releases.
2. **Deprecate Insecure Protocols:**
   - Migrate administrative shells from Telnet to OpenSSH with forced public key authentication (`PasswordAuthentication no`).
3. **Firewall & Rate Limiting (`iptables`):**
   ```bash
   # Block rogue root backdoor port
   sudo iptables -A INPUT -p tcp --dport 6200 -j DROP

   # Rate limit aggressive SYN scanning probes
   sudo iptables -A INPUT -p tcp --syn -m limit --limit 1/s --limit-burst 3 -j ACCEPT
   ```
4. **Intrusion Detection System Rule (`Snort`):**
   ```snort
   alert tcp any any -> $HOME_NET 21 (msg:"VSFTPD Backdoor Smiley Trigger"; content:":)"; sid:1000001; rev:1;)
   ```

---

## 📂 Project File Structure

```
ai-threat-detector/
├── package.json                          # Node.js project manifest & scripts
├── requirements.txt                      # Python dependencies for Kali Linux
├── server.js                             # Backend API server with socket scanner
├── README.md                             # Comprehensive repository documentation
├── .gitignore                            # Standard security project exclusions
├── data/
│   ├── cve_database.json                 # Curated vulnerability database & CVSS scores
│   ├── sample_traffic.json               # Realistic captured PCAP packet records
│   └── attack_signatures.json            # Threat detection rules & heuristic weights
├── public/
│   ├── index.html                        # SOC Security Dashboard Web UI
│   ├── css/
│   │   └── style.css                     # Dark-mode cybersecurity theme
│   └── js/
│       └── app.js                        # Client-side scanner, PCAP dissector & report generator
├── scripts/
│   ├── python/
│   │   ├── nmap_recon.py                 # Multi-stage automated Nmap scanner
│   │   ├── pcap_analyzer.py              # Packet traffic & entropy analyzer
│   │   ├── ai_threat_classifier.py       # Standalone AI threat classification engine
│   │   └── banner_grabber.py             # Multi-threaded socket banner grabber
│   └── bash/
│       ├── setup_lab.sh                  # Kali Linux & VirtualBox setup automation
│       └── capture_traffic.sh            # Tcpdump traffic capture utility
└── docs/
    ├── LAB_ENVIRONMENT_SETUP.md          # Step-by-step VirtualBox & Kali setup guide
    ├── PENETRATION_TESTING_GUIDE.md      # Detailed pentest methodology walkthrough
    ├── VULNERABILITY_ASSESSMENT_REPORT.md# Professional pentest report (NIST/PTES format)
    └── RESUME_AND_INTERVIEW_PREP.md      # Resume bullets, STAR stories & interview Q&A
```

---

## 🚀 Quick Start Guide

### Running the Interactive Security Dashboard
1. Ensure [Node.js](https://nodejs.org/) (v16+) is installed.
2. Clone or open this repository directory.
3. Start the server:
   ```bash
   npm start
   ```
4. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

### Running on Kali Linux
1. Clone this repository onto your Kali Linux VM.
2. Grant execution permissions to the scripts:
   ```bash
   chmod +x scripts/python/*.py scripts/bash/*.sh
   ```
3. Run the automated reconnaissance scan:
   ```bash
   python3 scripts/python/nmap_recon.py -t 192.168.56.102 --vuln
   ```
4. Run the packet traffic analyzer:
   ```bash
   python3 scripts/python/pcap_analyzer.py
   ```

---

## ⚖️ Legal & Ethical Disclaimer
This project is developed solely for educational purposes, authorized security testing, and defensive research. Conducting penetration tests or port scans against targets without prior written authorization is strictly illegal.
