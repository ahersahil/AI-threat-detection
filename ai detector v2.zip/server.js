/**
 * SentinelLab & AI Threat Detector
 * Network Penetration Testing & Vulnerability Assessment Lab Backend
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const net = require('net');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');

// Load Data
let cveDatabase = [];
let sampleTraffic = [];
let attackSignatures = {};
let owaspApiSecurity = [];
let osintCloudSecurity = {};

try {
  cveDatabase = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'cve_database.json'), 'utf8'));
  sampleTraffic = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'sample_traffic.json'), 'utf8'));
  attackSignatures = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'attack_signatures.json'), 'utf8'));
  owaspApiSecurity = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'owasp_api_security.json'), 'utf8'));
  osintCloudSecurity = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'osint_and_cloud_security.json'), 'utf8'));
} catch (err) {
  console.warn('Notice: Loading fallback data due to:', err.message);
}

// Shannon Entropy calculation for payload anomaly detection
function calculateEntropy(str) {
  if (!str || str.length === 0) return 0;
  const len = str.length;
  const frequencies = {};
  for (let i = 0; i < len; i++) {
    const char = str[i];
    frequencies[char] = (frequencies[char] || 0) + 1;
  }
  let entropy = 0;
  for (const char in frequencies) {
    const p = frequencies[char] / len;
    entropy -= p * Math.log2(p);
  }
  return parseFloat(entropy.toFixed(3));
}

// AI & Heuristic Threat Detection Engine
function runThreatDetection(packets) {
  const analysisResults = [];
  const srcIpFreq = {};
  const highRiskPorts = [21, 22, 23, 80, 139, 445, 3306, 3632, 6200, 4444];

  packets.forEach(pkt => {
    let threatScore = 0;
    const triggeredRules = [];
    const payload = pkt.payload_preview || '';
    const entropy = pkt.payload_entropy !== undefined ? pkt.payload_entropy : calculateEntropy(payload);
    const dstPort = parseInt(pkt.dst_port, 10);

    // Track source IP frequency (Port Scan detection)
    srcIpFreq[pkt.src_ip] = (srcIpFreq[pkt.src_ip] || 0) + 1;

    // Rule 1: Backdoor and Root Shell Ports
    if ([6200, 4444, 31337].includes(dstPort)) {
      threatScore += 45;
      triggeredRules.push({
        name: 'BACKDOOR_PORT_INTERACTION',
        severity: 'CRITICAL',
        desc: `Direct interaction with known backdoor/Meterpreter port ${dstPort}`
      });
    }

    // Rule 2: Payload Entropy Anomaly (High entropy indicates encrypted payload/shellcode)
    if (entropy > 4.5) {
      threatScore += 25;
      triggeredRules.push({
        name: 'HIGH_ENTROPY_SHELLCODE_SUSPECT',
        severity: 'HIGH',
        desc: `High Shannon entropy (${entropy} bits/symbol) indicating obfuscated shellcode or binary payload`
      });
    }

    // Rule 3: Known Exploit Signature Detection
    if (/:\)|DIST00000001|msfadmin|system\(|eval\(|base64_decode/i.test(payload)) {
      threatScore += 40;
      triggeredRules.push({
        name: 'EXPLOIT_SIGNATURE_MATCH',
        severity: 'CRITICAL',
        desc: 'Payload contains known exploit trigger signature (vsftpd backdoor trigger or DistCC payload header)'
      });
    }

    // Rule 4: Cleartext Credential Exposure
    if (/password|passwd|USER\s+|PASS\s+/i.test(payload) && [21, 23, 80].includes(dstPort)) {
      threatScore += 30;
      triggeredRules.push({
        name: 'CLEARTEXT_CREDENTIAL_INSPECTION',
        severity: 'HIGH',
        desc: `Unencrypted authentication credentials detected in cleartext on port ${dstPort}`
      });
    }

    // Rule 5: Web Attack Probes (LFI / SQLi)
    if (/\.\.\/|\.\.\\|' OR '|UNION SELECT|--/i.test(payload)) {
      threatScore += 35;
      triggeredRules.push({
        name: 'WEB_APPLICATION_ATTACK',
        severity: 'HIGH',
        desc: 'Web application injection probe (Directory Traversal / SQL Injection)'
      });
    }

    // Rule 6: SYN Probe Reconnaissance
    if (pkt.flags === 'SYN' && !pkt.payload_preview) {
      threatScore += 15;
      triggeredRules.push({
        name: 'RECON_SYN_PROBE',
        severity: 'LOW',
        desc: `Reconnaissance SYN packet targeting port ${dstPort}`
      });
    }

    // Normalize Threat Score (0 - 100)
    threatScore = Math.min(100, threatScore);
    let classification = 'BENIGN';
    if (threatScore >= 70) classification = 'CRITICAL';
    else if (threatScore >= 50) classification = 'HIGH';
    else if (threatScore >= 25) classification = 'MEDIUM';
    else if (threatScore > 0) classification = 'LOW';

    analysisResults.push({
      id: pkt.id || `PKT-${Math.floor(Math.random() * 9000 + 1000)}`,
      timestamp: pkt.timestamp || new Date().toISOString(),
      src: `${pkt.src_ip}:${pkt.src_port}`,
      dst: `${pkt.dst_ip}:${pkt.dst_port}`,
      protocol: pkt.protocol || 'TCP',
      flags: pkt.flags || 'N/A',
      entropy: entropy,
      threatScore: threatScore,
      classification: classification,
      confidence: (threatScore > 0 ? (0.75 + (threatScore / 400)).toFixed(2) : '0.99'),
      triggeredRules: triggeredRules,
      suggestedDefense: getDefenseGuidance(classification, triggeredRules, dstPort)
    });
  });

  return analysisResults;
}

function getDefenseGuidance(classification, rules, port) {
  if (classification === 'CRITICAL') {
    return `Immediate Incident Response: Isolate host, terminate rogue listener on port ${port}, and apply iptables rule: 'iptables -A INPUT -p tcp --dport ${port} -j DROP'.`;
  } else if (classification === 'HIGH') {
    return `Security Hardening: Disable cleartext protocols, enforce TLS/SSH, and sanitize input filters to prevent injection attacks.`;
  } else if (classification === 'MEDIUM') {
    return `Reconnaissance Defense: Implement rate limiting and IDS/IPS threshold alerts for SYN scanning.`;
  }
  return `Normal Traffic: Baseline traffic within normal operational parameters.`;
}

// Single TCP Port Probe
function probePort(host, port, timeout = 1200) {
  return new Promise(resolve => {
    const socket = new net.Socket();
    let status = 'closed';
    let banner = '';

    socket.setTimeout(timeout);

    socket.on('connect', () => {
      status = 'open';
      // Prompt for banner on certain ports
      if (port === 80 || port === 8080) {
        socket.write('HEAD / HTTP/1.0\r\n\r\n');
      } else {
        socket.write('\r\n');
      }
    });

    socket.on('data', data => {
      banner = data.toString('utf8').trim().replace(/[\r\n]+/g, ' ').substring(0, 80);
      socket.destroy();
    });

    socket.on('timeout', () => {
      status = 'filtered/timeout';
      socket.destroy();
    });

    socket.on('error', () => {
      status = 'closed';
    });

    socket.on('close', () => {
      const knownService = getServiceForPort(port);
      const matchedCve = cveDatabase.find(c => c.port === port);
      resolve({
        port,
        status,
        service: knownService,
        banner: banner || (status === 'open' ? 'Service responsive' : 'No banner'),
        vulnerability: matchedCve ? {
          cve: matchedCve.cve,
          severity: matchedCve.severity,
          title: matchedCve.title
        } : null
      });
    });

    socket.connect(port, host);
  });
}

function getServiceForPort(port) {
  const map = {
    21: 'FTP (File Transfer Protocol)',
    22: 'SSH (Secure Shell)',
    23: 'Telnet (Cleartext terminal)',
    25: 'SMTP (Mail Transfer)',
    53: 'DNS (Domain Name System)',
    80: 'HTTP (Web Server)',
    110: 'POP3 (Mail Retrieval)',
    139: 'NetBIOS / Samba',
    143: 'IMAP (Mail Retrieval)',
    443: 'HTTPS (Encrypted Web)',
    445: 'SMB (File Sharing)',
    3306: 'MySQL Database',
    3632: 'DistCC (Distributed Compiler)',
    5432: 'PostgreSQL Database',
    6200: 'vsftpd Backdoor Shell',
    8080: 'HTTP-Proxy / Alternative Web'
  };
  return map[port] || 'Unknown Service';
}

// MIME types helper
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.md': 'text/plain; charset=utf-8'
};

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // CORS headers for development flexibility
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // API Endpoints
  if (pathname.startsWith('/api/')) {
    handleApi(req, res, pathname);
    return;
  }

  // Static File Serving
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
});

// Route API requests
function handleApi(req, res, pathname) {
  if (pathname === '/api/status' && req.method === 'GET') {
    jsonResponse(res, 200, {
      status: 'ONLINE',
      system: 'SentinelLab Cybersecurity & AI Threat Detector',
      version: '2.5.0',
      nodeVersion: process.version,
      databaseStats: {
        totalCVEs: cveDatabase.length,
        samplePackets: sampleTraffic.length,
        activeRules: attackSignatures.signatures ? attackSignatures.signatures.length : 6
      },
      supportedFeatures: [
        'Active Network Reconnaissance & Port Scanning',
        'Wireshark / PCAP Packet Dissection & Credential Sniffing',
        'Shannon Entropy Anomaly Computation',
        'AI Threat Detection & Heuristic Classifier',
        'Metasploit CVE Vulnerability Correlation',
        'Automated Pentest Report Generation'
      ]
    });
  } else if (pathname === '/api/cves' && req.method === 'GET') {
    jsonResponse(res, 200, cveDatabase);
  } else if (pathname === '/api/traffic' && req.method === 'GET') {
    jsonResponse(res, 200, sampleTraffic);
  } else if (pathname === '/api/owasp-api' && req.method === 'GET') {
    jsonResponse(res, 200, owaspApiSecurity);
  } else if (pathname === '/api/osint-cloud' && req.method === 'GET') {
    jsonResponse(res, 200, osintCloudSecurity);
  } else if (pathname === '/api/detect-threats' && req.method === 'POST') {
    readBodyJson(req, res, body => {
      const packets = body.packets && body.packets.length > 0 ? body.packets : sampleTraffic;
      const analysis = runThreatDetection(packets);
      
      const criticalCount = analysis.filter(a => a.classification === 'CRITICAL').length;
      const highCount = analysis.filter(a => a.classification === 'HIGH').length;
      const mediumCount = analysis.filter(a => a.classification === 'MEDIUM').length;
      const benignCount = analysis.filter(a => a.classification === 'BENIGN' || a.classification === 'LOW').length;

      const overallRisk = criticalCount > 0 ? 'CRITICAL' : (highCount > 0 ? 'HIGH' : (mediumCount > 0 ? 'ELEVATED' : 'LOW'));

      jsonResponse(res, 200, {
        analyzedPacketsCount: analysis.length,
        overallThreatLevel: overallRisk,
        summary: {
          critical: criticalCount,
          high: highCount,
          medium: mediumCount,
          benign: benignCount
        },
        detections: analysis
      });
    });
  } else if (pathname === '/api/scan' && req.method === 'POST') {
    readBodyJson(req, res, async body => {
      const target = body.target || '127.0.0.1';
      // Default common lab ports
      const ports = body.ports && Array.isArray(body.ports) ? body.ports : [21, 22, 23, 25, 53, 80, 139, 443, 445, 3306, 3632, 6200, 8080];
      
      const startTime = Date.now();
      const results = [];

      for (const p of ports) {
        try {
          const res = await probePort(target, p, 800);
          results.push(res);
        } catch (e) {
          results.push({ port: p, status: 'error', service: getServiceForPort(p), error: e.message });
        }
      }

      const openPorts = results.filter(r => r.status === 'open');
      const scanDuration = (Date.now() - startTime) / 1000;

      jsonResponse(res, 200, {
        target,
        timestamp: new Date().toISOString(),
        durationSeconds: scanDuration,
        totalScanned: ports.length,
        openPortsCount: openPorts.length,
        results
      });
    });
  } else if (pathname === '/api/generate-report' && req.method === 'POST') {
    readBodyJson(req, res, body => {
      const reportMarkdown = generateMarkdownReport(body);
      jsonResponse(res, 200, {
        format: 'markdown',
        generatedAt: new Date().toISOString(),
        markdown: reportMarkdown
      });
    });
  } else {
    jsonResponse(res, 404, { error: 'Endpoint Not Found' });
  }
}

function generateMarkdownReport(data) {
  const target = data.target || '192.168.56.102 (Metasploitable2 Lab VM)';
  const tester = data.tester || 'Cybersecurity Lab Analyst';
  const findings = data.findings || cveDatabase;

  return `# Network Penetration Testing & Vulnerability Assessment Report

**Target Scope:** ${target}  
**Assessment Date:** ${new Date().toLocaleDateString()}  
**Lead Security Assessor:** ${tester}  
**Frameworks Referenced:** NIST SP 800-115, PTES, CVSS v3.1  

---

## 1. Executive Summary
During the controlled security assessment, multiple critical vulnerabilities were discovered within the target test environment. Vulnerabilities range from unauthenticated root command execution backdoors to unencrypted transmission of administrative credentials. Immediate remediation is strongly advised to prevent complete system compromise.

## 2. Identified Vulnerabilities Summary
| Port | Service | Vulnerability | Severity | CVSS |
| :--- | :--- | :--- | :--- | :--- |
${findings.map(f => `| ${f.port} | ${f.service} | ${f.title} | **${f.severity}** | ${f.cvss} |`).join('\n')}

---

## 3. Detailed Findings & Proof of Concept

### Finding 1: vsftpd 2.3.4 Backdoor Command Execution (CVE-2011-2523)
- **Severity:** CRITICAL (CVSS 9.8)
- **Impact:** Remote unauthenticated attacker achieves full root privilege.
- **Verification Command:**
  \`\`\`bash
  msfconsole -q -x "use exploit/unix/ftp/vsftpd_234_backdoor; set RHOSTS ${target.split(' ')[0]}; run"
  \`\`\`
- **Remediation:** Remove obsolete vsftpd version. Update to vsftpd >= 3.0.0.

### Finding 2: Cleartext Protocol Credential Exposure (CWE-319)
- **Severity:** HIGH (CVSS 6.5)
- **Impact:** Wireshark packet capture revealed plain-text credentials transmitted over Telnet/FTP.
- **Remediation:** Disable Telnet and migrate all remote shells to OpenSSH with public key authentication.

---

## 4. AI Threat Detector Defensive Countermeasures
- Deployed dynamic Snort / Suricata IDS signatures targeting malicious payloads.
- Implemented iptables rate limiting for TCP SYN port scanning probes.
`;
}

function readBodyJson(req, res, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk;
    if (body.length > 2e6) { // 2MB limit
      res.writeHead(413, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Payload Too Large' }));
      req.connection.destroy();
    }
  });
  req.on('end', () => {
    try {
      const parsed = body ? JSON.parse(body) : {};
      callback(parsed);
    } catch (e) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
    }
  });
}

function jsonResponse(res, statusCode, data) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data, null, 2));
}

server.listen(PORT, () => {
  console.log(`[+] SentinelLab & AI Threat Detector running at: http://localhost:${PORT}`);
  console.log(`[+] Ready for Network Reconnaissance, Wireshark Analysis & Threat Classification.`);
});
