#!/bin/bash
# SentinelLab Launcher for Linux / Kali Linux / macOS
echo "========================================================"
echo " Starting SentinelLab & AI Threat Detector..."
echo " Opening browser at http://localhost:3000"
echo "========================================================"

# Attempt to open default browser
if which xdg-open >/dev/null 2>&1; then
  xdg-open http://localhost:3000 &
elif which open >/dev/null 2>&1; then
  open http://localhost:3000 &
fi

# Start the Node.js server
node server.js
