#!/usr/bin/env python3
"""
SentinelLab - AI Threat Detection & Heuristic Classifier Engine
Combines statistical anomaly calculation, entropy analysis, and signature correlation.
"""

import sys
import os
import json
import math
import argparse
from datetime import datetime

class ThreatClassifier:
    def __init__(self, weights=None):
        self.weights = weights or {
            "entropy_threshold": 3.7,
            "backdoor_port_score": 50,
            "exploit_signature_score": 40,
            "cleartext_cred_score": 30,
            "syn_probe_score": 15
        }

    def compute_entropy(self, text):
        if not text:
            return 0.0
        counts = {}
        for c in text:
            counts[c] = counts.get(c, 0) + 1
        entropy = 0.0
        n = len(text)
        for count in counts.values():
            p = count / n
            entropy -= p * math.log2(p)
        return round(entropy, 3)

    def classify_packet(self, packet):
        score = 0
        reasons = []
        payload = packet.get("payload_preview", "")
        dst_port = int(packet.get("dst_port", 0))
        entropy = packet.get("payload_entropy", self.compute_entropy(payload))

        # Check Backdoors
        if dst_port in [6200, 4444, 31337]:
            score += self.weights["backdoor_port_score"]
            reasons.append(f"Metasploit / Root shell listener active on port {dst_port}")

        # Check Exploit Patterns
        if any(sig in payload for sig in [":)", "DIST00000001", "msfadmin"]):
            score += self.weights["exploit_signature_score"]
            reasons.append("Matched known remote code execution exploit pattern")

        # Check Cleartext Passwords
        if any(term in payload.lower() for term in ["password:", "pass ", "user "]) and dst_port in [21, 23]:
            score += self.weights["cleartext_cred_score"]
            reasons.append("Unencrypted credential broadcast on legacy protocol")

        # Check Recon Probes
        if packet.get("flags") == "SYN" and not payload:
            score += self.weights["syn_probe_score"]
            reasons.append("TCP SYN reconnaissance probe")

        # Entropy Check
        if entropy > self.weights["entropy_threshold"] and len(payload) > 30:
            score += 20
            reasons.append(f"Elevated payload entropy ({entropy} bits) indicating obfuscation")

        normalized_score = min(100, score)
        if normalized_score >= 70:
            severity = "CRITICAL"
        elif normalized_score >= 45:
            severity = "HIGH"
        elif normalized_score >= 20:
            severity = "MEDIUM"
        else:
            severity = "BENIGN"

        confidence = round(0.70 + (normalized_score / 350.0), 2) if normalized_score > 0 else 0.99

        return {
            "packet_id": packet.get("id", "UNKNOWN"),
            "score": normalized_score,
            "severity": severity,
            "confidence": min(0.99, confidence),
            "reasons": reasons
        }

def main():
    parser = argparse.ArgumentParser(description="SentinelLab AI Threat Classifier")
    parser.add_argument("-f", "--file", default="../../data/sample_traffic.json", help="Traffic JSON dataset")
    args = parser.parse_args()

    target_file = args.file
    if not os.path.exists(target_file):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        target_file = os.path.join(script_dir, "..", "..", "data", "sample_traffic.json")

    print("=" * 60)
    print(" SentinelLab AI Threat Detection Classifier")
    print(f" Timestamp: {datetime.now().isoformat()}")
    print("=" * 60)

    if not os.path.exists(target_file):
        print(f"[-] Cannot find traffic file: {target_file}")
        sys.exit(1)

    with open(target_file, "r") as f:
        packets = json.load(f)

    classifier = ThreatClassifier()
    critical_alerts = 0

    for pkt in packets:
        result = classifier.classify_packet(pkt)
        if result["severity"] != "BENIGN":
            print(f"[{result['severity']}] {result['packet_id']} -> Threat Score: {result['score']}/100 (Confidence: {result['confidence']})")
            for r in result["reasons"]:
                print(f"   * {r}")
            print("-" * 50)
            if result["severity"] == "CRITICAL":
                critical_alerts += 1

    print(f"\n[+] AI Evaluation Complete. Total Critical Incidents Detected: {critical_alerts}")

if __name__ == "__main__":
    main()
