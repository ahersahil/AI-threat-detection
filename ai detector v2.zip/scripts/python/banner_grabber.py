#!/usr/bin/env python3
"""
SentinelLab - Multi-threaded TCP Port Scanner & Service Banner Grabber
Uses Python's standard socket and threading libraries (Zero external dependencies).
"""

import socket
import threading
import sys
import argparse
from datetime import datetime

DEFAULT_PORTS = [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 445, 3306, 3632, 5432, 6200, 8080]

def grab_banner(ip, port, timeout=1.5):
    """Attempts to establish a TCP connection and read an initial banner."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((ip, port))
        
        # Trigger banner transmission if necessary
        if port in [80, 8080]:
            s.send(b"HEAD / HTTP/1.0\r\n\r\n")
        else:
            s.send(b"\r\n")

        banner = s.recv(1024).decode('utf-8', errors='ignore').strip()
        s.close()
        return banner.replace('\r', ' ').replace('\n', ' ')[:80]
    except Exception:
        return ""

def scan_worker(ip, port, results, lock):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1.2)
    result = s.connect_ex((ip, port))
    s.close()
    
    if result == 0:
        banner = grab_banner(ip, port)
        with lock:
            results.append((port, banner))
            print(f"[+] OPEN: Port {port}/tcp | Service Banner: {banner if banner else '[No banner returned]'}")

def main():
    parser = argparse.ArgumentParser(description="SentinelLab Multi-threaded Socket Scanner")
    parser.add_argument("-t", "--target", default="127.0.0.1", help="Target IP address (default: 127.0.0.1)")
    parser.add_argument("-p", "--ports", default=None, help="Comma-separated ports (e.g. 21,22,80,6200)")
    args = parser.parse_args()

    target = args.target
    ports = [int(p.strip()) for p in args.ports.split(",")] if args.ports else DEFAULT_PORTS

    print("=" * 60)
    print(f" SentinelLab Fast TCP Banner Grabber")
    print(f" Target: {target}")
    print(f" Ports:  {len(ports)} ports queued")
    print(f" Start:  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    threads = []
    results = []
    lock = threading.Lock()

    for p in ports:
        t = threading.Thread(target=scan_worker, args=(target, p, results, lock))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print("=" * 60)
    print(f"[+] Scan completed. Discovered {len(results)} open ports on {target}.")

if __name__ == "__main__":
    main()
