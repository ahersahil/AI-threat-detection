#!/usr/bin/env python3
"""
SentinelLab - Network Packet Traffic & Wireshark Dissector Script
Analyzes PCAP streams or JSON logs to detect credential leakage, exploit payloads, and port scans.
Usage: python3 pcap_analyzer.py [-f <PCAP_OR_JSON_FILE>] [--entropy-threshold 3.5]
"""

import sys
import os
import json
import math
import re
import argparse
from datetime import datetime

def calculate_shannon_entropy(data_str):
    """Computes Shannon entropy (bits per symbol) to detect encrypted/obfuscated payloads."""
    if not data_str:
        return 0.0
    length = len(data_str)
    freq = {}
    for char in data_str:
        freq[char] = freq.get(char, 0) + 1
    entropy = 0.0
    for count in freq.values():
        p = count / length
        entropy -= p * math.log2(p)
    return round(entropy, 3)

def inspect_packet(packet, entropy_threshold=3.5):
    """Inspects a packet dictionary for suspicious patterns."""
    alerts = []
    payload = packet.get("payload_preview", "")
    entropy = packet.get("payload_entropy", calculate_shannon_entropy(payload))
    dst_port = int(packet.get("dst_port", 0))
    src_port = int(packet.get("src_port", 0))

    # 1. Backdoor Ports
    if dst_port in [6200, 4444, 31337] or src_port in [6200, 4444, 31337]:
        alerts.append({
            "level": "CRITICAL",
            "type": "BACKDOOR_INTERACTION",
            "detail": f"Direct connection detected on known backdoor/shell port {dst_port or src_port}."
        })

    # 2. Known Exploit Signatures
    if ":)" in payload:
        alerts.append({
            "level": "CRITICAL",
            "type": "VSFTPD_BACKDOOR_TRIGGER",
            "detail": "vsftpd 2.3.4 smiley trigger detected in username string (CVE-2011-2523)."
        })
    if "DIST00000001" in payload:
        alerts.append({
            "level": "CRITICAL",
            "type": "DISTCC_RCE_EXPLOIT",
            "detail": "DistCC remote code execution payload header detected (CVE-2004-2687)."
        })

    # 3. Cleartext Credentials
    cred_pattern = re.compile(r"(password|PASS\s+|USER\s+|Authorization:\s*Basic)", re.IGNORECASE)
    if cred_pattern.search(payload) and dst_port in [21, 23, 80]:
        alerts.append({
            "level": "HIGH",
            "type": "CLEARTEXT_CREDENTIAL_LEAK",
            "detail": f"Unencrypted authentication data observed in transit on port {dst_port}."
        })

    # 4. High Entropy Obfuscation
    if entropy > entropy_threshold and len(payload) > 20:
        alerts.append({
            "level": "MEDIUM",
            "type": "HIGH_ENTROPY_ANOMALY",
            "detail": f"Payload entropy {entropy} exceeds normal plaintext baseline ({entropy_threshold})."
        })

    return alerts

def main():
    parser = argparse.ArgumentParser(description="SentinelLab Network Packet Traffic Dissector")
    parser.add_argument("-f", "--file", default="../../data/sample_traffic.json", help="Path to traffic JSON or PCAP export")
    parser.add_argument("-e", "--entropy-threshold", type=float, default=3.7, help="Entropy threshold for anomaly flagging")
    args = parser.parse_args()

    # Resolve relative path
    target_file = args.file
    if not os.path.exists(target_file):
        # Look in data folder
        script_dir = os.path.dirname(os.path.abspath(__file__))
        target_file = os.path.join(script_dir, "..", "..", "data", "sample_traffic.json")

    print(f"""
    ==========================================================
     SentinelLab Wireshark & Traffic Packet Dissector
     Target Log File: {target_file}
     Entropy Limit:   {args.entropy_threshold}
    ==========================================================
    """)

    if not os.path.exists(target_file):
        print(f"[-] Error: Could not locate traffic file at: {target_file}")
        sys.exit(1)

    with open(target_file, "r") as f:
        packets = json.load(f)

    total_packets = len(packets)
    flagged_count = 0
    print(f"[+] Loaded {total_packets} packets for deep protocol inspection.\n")

    for idx, pkt in enumerate(packets, 1):
        alerts = inspect_packet(pkt, args.entropy_threshold)
        if alerts:
            flagged_count += 1
            print(f"[*] [ALERT] Packet #{idx} ({pkt.get('id', 'N/A')}) | {pkt.get('src_ip')}:{pkt.get('src_port')} -> {pkt.get('dst_ip')}:{pkt.get('dst_port')}")
            for a in alerts:
                print(f"    - [{a['level']}] {a['type']}: {a['detail']}")
            if pkt.get("payload_preview"):
                print(f"    - Payload: {repr(pkt.get('payload_preview')[:60])}")
            print("")

    print("----------------------------------------------------------")
    print(f"[+] Inspection complete. Flagged {flagged_count} of {total_packets} packets.")
    print("----------------------------------------------------------")

if __name__ == "__main__":
    main()
