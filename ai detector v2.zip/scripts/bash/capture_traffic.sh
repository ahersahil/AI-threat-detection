#!/bin/bash
# SentinelLab - Automated Tcpdump Packet Capture Utility
# Captures traffic between Kali and target VM for Wireshark inspection.

IFACE="${1:-eth1}"
TARGET_IP="${2:-192.168.56.102}"
OUTPUT_FILE="lab_traffic_$(date +%Y%m%d_%H%M%S).pcap"

echo "=========================================================="
echo " SentinelLab Wireshark Packet Capture Utility"
echo " Interface: $IFACE"
echo " Target IP:  $TARGET_IP"
echo " Capture Output: $OUTPUT_FILE"
echo "=========================================================="

if [ "$EUID" -ne 0 ]; then
  echo "[!] Please run with sudo: sudo ./capture_traffic.sh [IFACE] [TARGET_IP]"
  exit 1
fi

echo "[*] Starting tcpdump capture. Press CTRL+C to terminate..."
tcpdump -i "$IFACE" host "$TARGET_IP" -w "$OUTPUT_FILE" -v
