#!/bin/bash
# SentinelLab - Kali Linux & VirtualBox Lab Setup Script
# Configures networking, verifies target connectivity, and checks required tools.

set -e

echo "=========================================================="
echo " SentinelLab Environment Initializer"
echo "=========================================================="

# Check Root
if [ "$EUID" -ne 0 ]; then
  echo "[!] Please run as root (sudo ./setup_lab.sh)"
  exit 1
fi

echo "[*] Checking essential penetration testing utilities..."
REQUIRED_PKGS=("nmap" "wireshark" "tshark" "tcpdump" "metasploit-framework" "python3" "curl")

for pkg in "${REQUIRED_PKGS[@]}"; do
  if which "$pkg" >/dev/null 2>&1; then
    echo "  [✓] $pkg is installed."
  else
    echo "  [✗] $pkg is missing. Installing via apt..."
    apt-get update -qq && apt-get install -y -qq "$pkg"
  fi
done

# Check Host-Only Interface
echo ""
echo "[*] Detecting VirtualBox Host-Only / Internal adapter..."
IFACE=$(ip -o -4 addr show | awk '$4 ~ /^192\.168\.56\./ {print $2}' | head -n 1)

if [ -n "$IFACE" ]; then
  IP=$(ip -o -4 addr show dev "$IFACE" | awk '{print $4}')
  echo "[+] Detected VirtualBox Host-Only network adapter: $IFACE ($IP)"
else
  echo "[!] Note: Default host-only subnet 192.168.56.0/24 not detected."
  echo "    Ensure VirtualBox 'Host-Only Ethernet Adapter' is attached to eth1 or vboxnet0."
fi

# Metasploit Database Init
echo ""
echo "[*] Ensuring PostgreSQL and Metasploit Database are initialized..."
systemctl start postgresql
msfdb init || true

echo ""
echo "=========================================================="
echo "[+] SentinelLab setup complete! Ready for security audit."
echo "=========================================================="
