# Virtual Penetration Testing Lab Environment Setup Guide

This guide details the exact steps required to construct an isolated, secure, and reproducible cybersecurity practice lab using **Oracle VirtualBox**, **Kali Linux**, and **Metasploitable2**.

---

## 1. Network Topology & Architecture

To prevent malicious traffic from spilling onto your home or corporate LAN, all testing must occur within a dedicated **Host-Only Virtual Network**.

```
+------------------------------------------------------------+
|                    VirtualBox Hypervisor                   |
|                                                            |
|   +-----------------------+      +-----------------------+ |
|   |   Kali Linux 2026.x   |      |    Metasploitable 2   | |
|   |     (Attacker VM)     |      |      (Target VM)      | |
|   |                       |      |                       | |
|   | eth0: NAT (Internet)  |      |                       | |
|   | eth1: 192.168.56.101  | <==> | eth0: 192.168.56.102  | |
|   +-----------------------+      +-----------------------+ |
|               \                              /             |
|                \                            /              |
|          VirtualBox Host-Only Adapter (vboxnet0)           |
|                    Subnet: 192.168.56.0/24                 |
+------------------------------------------------------------+
```

---

## 2. Prerequisites & Software Downloads

1. **VirtualBox Hypervisor & Extension Pack**:
   - Download VirtualBox 7.x+ from [virtualbox.org](https://www.virtualbox.org/).
2. **Kali Linux Virtual Machine**:
   - Download the official pre-built VirtualBox `.ova` image from [kali.org/get-kali](https://www.kali.org/get-kali/).
3. **Metasploitable 2**:
   - Download the intentionally vulnerable Linux virtual machine image (`Metasploitable.vmdk`) from SourceForge or Rapid7.

---

## 3. Configuring VirtualBox Host-Only Network

1. Open VirtualBox and navigate to **Tools** -> **Network** -> **Host-only Networks**.
2. Click **Create** to initialize an adapter (typically named `vboxnet0` on Linux/macOS or `VirtualBox Host-Only Ethernet Adapter` on Windows).
3. Set the IPv4 configuration:
   - **IPv4 Address:** `192.168.56.1`
   - **IPv4 Network Mask:** `255.255.255.0`
4. Enable or disable the DHCP server based on preference (recommended: enable DHCP with range `192.168.56.100` - `192.168.56.200`).

---

## 4. Configuring VM Network Adapters

### A. Kali Linux (Attacker Machine)
1. Go to **Settings** -> **Network**.
2. **Adapter 1**: Set to **NAT** (allows Kali to access the internet for updates, package installations, and git repositories).
3. **Adapter 2**: Enable adapter and set to **Host-Only Adapter** (`vboxnet0`). This interface connects directly to the vulnerable target.

### B. Metasploitable 2 (Target Machine)
1. Go to **Settings** -> **Network**.
2. **Adapter 1**: Set to **Host-Only Adapter** (`vboxnet0`).
   > **CRITICAL SECURITY NOTE:** Never attach Metasploitable2 to **Bridged Adapter** or **NAT with Port Forwarding**. It contains dozens of known remote root backdoors and should NEVER be exposed to the public internet or external local network.

---

## 5. Verifying Lab Connectivity

1. Start both VMs.
2. Log into Metasploitable2:
   - **Username:** `msfadmin`
   - **Password:** `msfadmin`
3. Retrieve target IP address:
   ```bash
   ifconfig eth0
   # Verify IP is in 192.168.56.x range (e.g., 192.168.56.102)
   ```
4. On Kali Linux, verify connectivity using ICMP ping:
   ```bash
   ping -c 3 192.168.56.102
   ```
   If packets return successfully with 0% packet loss, your lab environment is fully operational!
