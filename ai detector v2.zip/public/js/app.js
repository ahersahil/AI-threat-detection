/**
 * SENTINEL // Command Center & AI Threat Engine Controller
 */

document.addEventListener('DOMContentLoaded', () => {
  // Global State
  let globalCves = [];
  let globalPackets = [];
  let currentPcapFilter = 'ALL';
  let audioEnabled = true;

  // DOM Elements - Navigation & Core
  const navItems = document.querySelectorAll('.nav-item');
  const viewPanes = document.querySelectorAll('.view-pane');
  const liveSocClock = document.getElementById('liveSocClock');
  const audioToggleBtn = document.getElementById('audioToggleBtn');
  const globalSearchInput = document.getElementById('globalSearchInput');
  const btnQuickAudit = document.getElementById('btnQuickAudit');
  const termLiveLog = document.getElementById('termLiveLog');

  // Scanner Elements
  const btnRunScan = document.getElementById('btnRunScan');
  const scanTargetInput = document.getElementById('scanTargetInput');
  const scanProfileSelect = document.getElementById('scanProfileSelect');
  const commandPreviewText = document.getElementById('commandPreviewText');
  const btnCopyScanCmd = document.getElementById('btnCopyScanCmd');
  const scanProgress = document.getElementById('scanProgress');
  const scanResultsBody = document.getElementById('scanResultsBody');

  // Wireshark Elements
  const pcapTableBody = document.getElementById('pcapTableBody');
  const packetDetailContent = document.getElementById('packetDetailContent');
  const inspectorPktId = document.getElementById('inspectorPktId');
  const pcapChips = document.querySelectorAll('.pcap-chip');
  const btnLoadSampleTraffic = document.getElementById('btnLoadSampleTraffic');
  const sidePcapCount = document.getElementById('sidePcapCount');
  const kpiPacketCount = document.getElementById('kpiPacketCount');

  // AI Threat Elements
  const btnRunAiThreatAnalysis = document.getElementById('btnRunAiThreatAnalysis');
  const aiDetectionsList = document.getElementById('aiDetectionsList');
  const aiCountCritical = document.getElementById('aiCountCritical');
  const aiCountHigh = document.getElementById('aiCountHigh');
  const aiCountMedium = document.getElementById('aiCountMedium');
  const aiCountBenign = document.getElementById('aiCountBenign');
  const sideThreatScore = document.getElementById('sideThreatScore');

  // CVE & Metasploit Elements
  const cveGrid = document.getElementById('cveGrid');
  const kpiCveCount = document.getElementById('kpiCveCount');

  // Report Elements
  const btnGenerateReport = document.getElementById('btnGenerateReport');
  const btnPrintReport = document.getElementById('btnPrintReport');
  const reportTargetInput = document.getElementById('reportTargetInput');
  const reportAuthorInput = document.getElementById('reportAuthorInput');
  const reportOutput = document.getElementById('reportOutput');

  // Canvas
  const radarCanvas = document.getElementById('radarCanvas');

  // Theme Dots
  const themeDots = document.querySelectorAll('.theme-dot');
  themeDots.forEach(dot => {
    dot.addEventListener('click', () => {
      const theme = dot.getAttribute('data-theme');
      themeDots.forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
      document.body.className = 'theme-dark';
      if (theme !== 'cyan') document.body.classList.add('theme-' + theme);
      playSound('click');
    });
  });

  // 1. Audio FX Generator (Web Audio API - No external files needed)
  let audioCtx = null;
  function playSound(type) {
    if (!audioEnabled) return;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      const now = audioCtx.currentTime;
      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'alert') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.setValueAtTime(840, now + 0.08);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'scan') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.exponentialRampToValueAtTime(900, now + 0.15);
        gain.gain.setValueAtTime(0.03, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
      }
    } catch (e) {
      // AudioContext not allowed before user gesture
    }
  }

  audioToggleBtn.addEventListener('click', () => {
    audioEnabled = !audioEnabled;
    audioToggleBtn.classList.toggle('muted', !audioEnabled);
    audioToggleBtn.querySelector('span').textContent = audioEnabled ? 'Audio FX: ON' : 'Audio FX: OFF';
    if (audioEnabled) playSound('click');
  });

  // 2. Real-Time UTC Clock
  function updateClock() {
    const now = new Date();
    liveSocClock.textContent = now.toTimeString().split(' ')[0] + ' UTC';
  }
  setInterval(updateClock, 1000);
  updateClock();

  // 3. Log Appender
  function appendLog(level, message) {
    const row = document.createElement('div');
    row.className = `log-row ${level}`;
    const timeStr = new Date().toTimeString().split(' ')[0];
    row.innerHTML = `<span class="log-time">[${timeStr}]</span> ${message}`;
    termLiveLog.appendChild(row);
    termLiveLog.scrollTop = termLiveLog.scrollHeight;
  }

  // 4. Tab Navigation
  navItems.forEach(btn => {
    btn.addEventListener('click', () => {
      playSound('click');
      const targetTab = btn.getAttribute('data-tab');
      navItems.forEach(b => b.classList.remove('active'));
      viewPanes.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const pane = document.getElementById(targetTab);
      if (pane) pane.classList.add('active');
    });
  });

  // 5. Radar Sweep Canvas Animation
  if (radarCanvas) {
    const ctx = radarCanvas.getContext('2d');
    let angle = 0;
    const centerX = radarCanvas.width / 2;
    const centerY = radarCanvas.height / 2;
    const radius = 135;

    const blips = [
      { x: centerX + 55, y: centerY - 45, color: '#ff2a6d', pulse: 0, label: 'Port 6200 (Backdoor)' },
      { x: centerX - 65, y: centerY + 50, color: '#00f0ff', pulse: 0, label: 'Nmap SYN Probe' },
      { x: centerX + 80, y: centerY + 40, color: '#10b981', pulse: 0, label: 'DNS Frame' },
      { x: centerX - 30, y: centerY - 70, color: '#f59e0b', pulse: 0, label: 'Telnet Cleartext' }
    ];

    function drawRadar() {
      ctx.clearRect(0, 0, radarCanvas.width, radarCanvas.height);

      // Rings
      ctx.strokeStyle = '#152540';
      ctx.lineWidth = 1;
      for (let r = 35; r <= radius; r += 35) {
        ctx.beginPath();
        ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Crosshairs
      ctx.beginPath();
      ctx.moveTo(centerX - radius, centerY);
      ctx.lineTo(centerX + radius, centerY);
      ctx.moveTo(centerX, centerY - radius);
      ctx.lineTo(centerX, centerY + radius);
      ctx.stroke();

      // Sweep Beam
      const sweepEnd = {
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius
      };

      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
      gradient.addColorStop(0, 'rgba(0, 240, 255, 0.02)');
      gradient.addColorStop(1, 'rgba(0, 240, 255, 0.22)');

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, angle - 0.45, angle);
      ctx.closePath();
      ctx.fillStyle = gradient;
      ctx.fill();
      ctx.restore();

      // Sweep Line
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(sweepEnd.x, sweepEnd.y);
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.85)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Blips
      blips.forEach(b => {
        ctx.beginPath();
        ctx.arc(b.x, b.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = b.color;
        ctx.fill();

        // Pulsing halo
        b.pulse += 0.05;
        const pulseR = 4 + Math.sin(b.pulse) * 4;
        ctx.beginPath();
        ctx.arc(b.x, b.y, pulseR, 0, Math.PI * 2);
        ctx.strokeStyle = b.color;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      });

      angle += 0.035;
      requestAnimationFrame(drawRadar);
    }
    drawRadar();
  }

  // 6. Command Preview & Copy
  function updateCommandPreview() {
    const target = scanTargetInput.value.trim() || '127.0.0.1';
    const profile = scanProfileSelect.value;
    let flags = '-sV -sC -O -T4';
    if (profile === 'quick') flags = '-sS -T4 -F';
    else if (profile === 'vuln') flags = '-sV --script vuln';
    else if (profile === 'all') flags = '-p- -A -T4';
    commandPreviewText.textContent = `nmap ${flags} ${target}`;
  }
  scanTargetInput.addEventListener('input', updateCommandPreview);
  scanProfileSelect.addEventListener('change', updateCommandPreview);

  btnCopyScanCmd.addEventListener('click', () => {
    navigator.clipboard.writeText(commandPreviewText.textContent);
    btnCopyScanCmd.textContent = 'Copied!';
    playSound('click');
    setTimeout(() => { btnCopyScanCmd.textContent = 'Copy'; }, 1500);
  });

  // 7. Initial Data Fetch
  async function loadInitialData() {
    try {
      // CVEs
      const cveRes = await fetch('/api/cves');
      globalCves = await cveRes.json();
      kpiCveCount.textContent = `${globalCves.length} Identified`;
      renderCveCards(globalCves);

      // Traffic
      const trafficRes = await fetch('/api/traffic');
      globalPackets = await trafficRes.json();
      sidePcapCount.textContent = globalPackets.length;
      kpiPacketCount.textContent = `${globalPackets.length} Packets`;
      renderPcapTable(globalPackets);
      if (globalPackets.length > 2) showPacketDetail(globalPackets[2]); // Default vsftpd packet

      // Threat Classification
      runThreatAnalysis();

      // Sample Port Scan Results
      renderDefaultScanResults();

      // Report
      generateReport();
    } catch (e) {
      console.error('Failed to load initial lab state:', e);
    }
  }

  // 8. Port Scanner Trigger
  btnRunScan.addEventListener('click', async () => {
    const target = scanTargetInput.value.trim() || '127.0.0.1';
    scanProgress.style.display = 'block';
    btnRunScan.disabled = true;
    playSound('scan');
    appendLog('info', `[SCAN] Initiating TCP port probe against target: ${target}`);

    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target })
      });
      const data = await res.json();
      renderScanResults(data.results);
      appendLog('info', `[SCAN] Completed in ${data.durationSeconds}s. Found ${data.openPortsCount} open services.`);
      playSound('alert');
    } catch (err) {
      appendLog('alert', `[SCAN ERROR] ${err.message}`);
    } finally {
      scanProgress.style.display = 'none';
      btnRunScan.disabled = false;
    }
  });

  function renderScanResults(results) {
    scanResultsBody.innerHTML = '';
    results.forEach(r => {
      const row = document.createElement('tr');
      const isOpen = r.status === 'open';
      const statusBadge = isOpen 
        ? `<span class="badge badge-low">OPEN</span>` 
        : (r.status.includes('filtered') ? `<span class="badge badge-high">FILTERED</span>` : `<span style="color:var(--text-muted);">CLOSED</span>`);
      
      const vulnBadge = r.vulnerability 
        ? `<span class="badge badge-critical">${r.vulnerability.cve}</span> <span style="font-size:0.75rem; color:var(--red);">(${r.vulnerability.severity})</span>`
        : `<span style="color:var(--text-muted);">Secure / Baseline</span>`;

      row.innerHTML = `
        <td><strong style="color: ${isOpen ? 'var(--cyan)' : 'inherit'};">${r.port}/TCP</strong></td>
        <td>${statusBadge}</td>
        <td><strong>${r.service}</strong></td>
        <td><code>${escapeHtml(r.banner || 'N/A')}</code></td>
        <td>${vulnBadge}</td>
      `;
      scanResultsBody.appendChild(row);
    });
  }

  function renderDefaultScanResults() {
    const mock = [
      { port: 21, status: 'open', service: 'vsftpd 2.3.4', banner: '220 (vsFTPd 2.3.4)', vulnerability: { cve: 'CVE-2011-2523', severity: 'CRITICAL' } },
      { port: 22, status: 'open', service: 'OpenSSH 4.7p1', banner: 'SSH-2.0-OpenSSH_4.7p1 Debian', vulnerability: { cve: 'CVE-2008-0166', severity: 'HIGH' } },
      { port: 23, status: 'open', service: 'Linux telnetd', banner: 'Cleartext Telnet Daemon', vulnerability: { cve: 'CWE-319', severity: 'MEDIUM' } },
      { port: 80, status: 'open', service: 'Apache HTTPD', banner: 'Apache/2.2.8 (Ubuntu) DAV/2', vulnerability: null },
      { port: 139, status: 'open', service: 'Samba smbd', banner: 'Samba 3.0.20-Debian', vulnerability: { cve: 'CVE-2007-2447', severity: 'CRITICAL' } },
      { port: 3632, status: 'open', service: 'distccd 3.1.1', banner: 'DIST00000001 (daemon)', vulnerability: { cve: 'CVE-2004-2687', severity: 'HIGH' } },
      { port: 6200, status: 'open', service: 'vsftpd Root Backdoor', banner: 'uid=0(root) gid=0(root)', vulnerability: { cve: 'CVE-2011-2523', severity: 'CRITICAL' } }
    ];
    renderScanResults(mock);
  }

  // 9. Wireshark PCAP Inspector
  pcapChips.forEach(chip => {
    chip.addEventListener('click', () => {
      playSound('click');
      pcapChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentPcapFilter = chip.getAttribute('data-filter');
      applyPcapFilter();
    });
  });

  function applyPcapFilter() {
    let filtered = globalPackets;
    if (currentPcapFilter === 'TCP') filtered = globalPackets.filter(p => p.protocol === 'TCP');
    else if (currentPcapFilter === 'FTP') filtered = globalPackets.filter(p => p.dst_port === 21 || p.src_port === 21);
    else if (currentPcapFilter === 'TELNET') filtered = globalPackets.filter(p => p.dst_port === 23 || p.src_port === 23);
    else if (currentPcapFilter === 'HTTP') filtered = globalPackets.filter(p => p.dst_port === 80 || p.src_port === 80);
    else if (currentPcapFilter === 'BACKDOOR') filtered = globalPackets.filter(p => p.dst_port === 6200 || p.src_port === 6200);
    renderPcapTable(filtered);
  }

  function renderPcapTable(packets) {
    pcapTableBody.innerHTML = '';
    packets.forEach((p, idx) => {
      const row = document.createElement('tr');
      row.classList.add('clickable');
      
      let badge = 'badge-low';
      if (p.risk_level === 'CRITICAL') badge = 'badge-critical';
      else if (p.risk_level === 'HIGH') badge = 'badge-high';

      row.innerHTML = `
        <td>${p.id}</td>
        <td>${p.timestamp ? p.timestamp.substring(11, 19) : '10:14:02'}</td>
        <td>${p.src_ip}:${p.src_port}</td>
        <td>${p.dst_ip}:${p.dst_port}</td>
        <td><strong>${p.protocol}</strong></td>
        <td><code>${p.flags}</code></td>
        <td><span class="badge ${badge}">${p.simulated_attack_type || p.risk_level}</span></td>
      `;

      row.addEventListener('click', () => {
        playSound('click');
        document.querySelectorAll('#pcapTableBody tr').forEach(r => r.classList.remove('selected'));
        row.classList.add('selected');
        showPacketDetail(p);
      });

      pcapTableBody.appendChild(row);
    });
  }

  function showPacketDetail(pkt) {
    inspectorPktId.textContent = pkt.id;
    const rawPayload = pkt.payload_preview || '[TCP SYN Handshake / Empty Payload]';
    const hex = toHexDump(rawPayload);

    packetDetailContent.innerHTML = `
<strong>[ PACKET IDENTIFIER: ${pkt.id} ]</strong>
Source: ${pkt.src_ip}:${pkt.src_port}  ➔  Destination: ${pkt.dst_ip}:${pkt.dst_port}
Protocol: ${pkt.protocol} | Flags: [${pkt.flags}] | Payload Length: ${pkt.length} bytes
Calculated Shannon Entropy: ${pkt.payload_entropy} bits/symbol

<strong>--- DECODED ASCII STREAM ---</strong>
${escapeHtml(rawPayload)}

<strong>--- HEX DISASSEMBLY ---</strong>
${hex}

<strong>--- ANALYST LAB NOTES ---</strong>
${pkt.notes || 'Routine traffic frame.'}
    `.trim();
  }

  function toHexDump(str) {
    if (!str) return '0000  00 00 00 00 00 00 00 00  ........';
    let hex = '';
    for (let i = 0; i < Math.min(str.length, 64); i++) {
      const code = str.charCodeAt(i).toString(16).padStart(2, '0');
      hex += code + ' ';
      if ((i + 1) % 8 === 0) hex += ' ';
    }
    return hex;
  }

  btnLoadSampleTraffic.addEventListener('click', () => {
    playSound('click');
    currentPcapFilter = 'ALL';
    pcapChips.forEach(c => c.classList.remove('active'));
    pcapChips[0].classList.add('active');
    renderPcapTable(globalPackets);
    if (globalPackets.length > 2) showPacketDetail(globalPackets[2]);
    appendLog('info', '[PCAP] Reloaded 10 default lab network packets.');
  });

  // 10. AI Threat Detection
  btnRunAiThreatAnalysis.addEventListener('click', () => {
    playSound('scan');
    runThreatAnalysis();
  });

  async function runThreatAnalysis() {
    try {
      const res = await fetch('/api/detect-threats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packets: globalPackets })
      });
      const data = await res.json();

      aiCountCritical.textContent = data.summary.critical;
      aiCountHigh.textContent = data.summary.high;
      aiCountMedium.textContent = data.summary.medium;
      aiCountBenign.textContent = data.summary.benign;

      const score = Math.min(100, (data.summary.critical * 25) + (data.summary.high * 15) + (data.summary.medium * 5));
      sideThreatScore.textContent = `${score}%`;

      aiDetectionsList.innerHTML = '';
      data.detections.forEach(det => {
        if (det.classification === 'BENIGN') return;
        const card = document.createElement('div');
        card.className = `detection-card ${det.classification}`;
        const rules = det.triggeredRules.map(r => `• <strong>${r.name}:</strong> ${r.desc}`).join('<br>');

        card.innerHTML = `
          <div class="det-header">
            <div>
              <span class="badge ${det.classification === 'CRITICAL' ? 'badge-critical' : 'badge-high'}">${det.classification}</span>
              <strong style="margin-left: 0.6rem; color: #fff;">${det.id} [${det.src} ➔ ${det.dst}]</strong>
            </div>
            <div style="color: var(--cyan); font-size: 0.8rem;">Confidence: ${(det.confidence * 100).toFixed(0)}%</div>
          </div>
          <div class="det-rule">${rules}</div>
          <div class="det-defense"><strong>🛡️ Automated Mitigation:</strong> ${det.suggestedDefense}</div>
        `;
        aiDetectionsList.appendChild(card);
      });

      appendLog('alert', `[AI-ENGINE] Processed ${data.analyzedPacketsCount} frames. Overall threat level: ${data.overallThreatLevel}.`);
    } catch (e) {
      console.error('Threat engine failure:', e);
    }
  }

  // 11. CVE Grid
  function renderCveCards(cves) {
    cveGrid.innerHTML = '';
    cves.forEach(c => {
      const card = document.createElement('div');
      card.className = 'cve-card';
      const badgeClass = c.severity === 'CRITICAL' ? 'badge-critical' : (c.severity === 'HIGH' ? 'badge-high' : 'badge-low');

      card.innerHTML = `
        <div>
          <div class="cve-card-top">
            <span class="cve-id">${c.cve}</span>
            <span class="badge ${badgeClass}">${c.severity} (${c.cvss})</span>
          </div>
          <h4 class="cve-title">${c.title}</h4>
          <p class="cve-desc">${c.description}</p>
        </div>
        <div class="cve-meta">
          <div><strong>Port:</strong> ${c.port}/TCP (${c.service})</div>
          <div><strong>MSF Module:</strong> <code>${c.metasploit_module}</code></div>
          <div style="color: var(--green); margin-top: 0.35rem;"><strong>Remediation:</strong> ${c.remediation}</div>
        </div>
      `;
      cveGrid.appendChild(card);
    });
  }

  // 12. Report Generator
  btnGenerateReport.addEventListener('click', () => {
    playSound('click');
    generateReport();
  });

  async function generateReport() {
    const target = reportTargetInput.value.trim() || '192.168.56.102 (Metasploitable2)';
    const tester = reportAuthorInput.value.trim() || 'Cybersecurity Analyst';

    try {
      const res = await fetch('/api/generate-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target, tester, findings: globalCves })
      });
      const data = await res.json();
      renderMarkdownReport(data.markdown);
    } catch (e) {
      console.error('Failed to generate report:', e);
    }
  }

  function renderMarkdownReport(md) {
    let html = md
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
      .replace(/```bash([\s\S]*?)```/gim, '<pre><code>$1</code></pre>')
      .replace(/`([^`]+)`/gim, '<code>$1</code>')
      .replace(/\n\n/gim, '<br>');

    if (html.includes('|')) {
      const lines = html.split('<br>');
      let tableHtml = '<table>';
      let inTable = false;

      lines.forEach(line => {
        if (line.trim().startsWith('|')) {
          if (!inTable) inTable = true;
          const cells = line.split('|').filter((c, idx, arr) => idx > 0 && idx < arr.length - 1);
          if (line.includes('---')) return;
          const isHeader = !tableHtml.includes('<tbody>');
          if (isHeader && !tableHtml.includes('<thead>')) {
            tableHtml += '<thead><tr>' + cells.map(c => `<th>${c.trim()}</th>`).join('') + '</tr></thead><tbody>';
          } else {
            tableHtml += '<tr>' + cells.map(c => `<td>${c.trim()}</td>`).join('') + '</tr>';
          }
        } else {
          if (inTable) {
            tableHtml += '</tbody></table>';
            inTable = false;
          }
        }
      });
      if (inTable) tableHtml += '</tbody></table>';
      reportOutput.innerHTML = tableHtml + html.replace(/\|.*\|/g, '');
    } else {
      reportOutput.innerHTML = html;
    }
  }

  btnPrintReport.addEventListener('click', () => {
    playSound('click');
    window.print();
  });

  // 13. Global Search Filter
  globalSearchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase().trim();
    if (!query) {
      renderCveCards(globalCves);
      renderPcapTable(globalPackets);
      return;
    }

    // Filter CVEs
    const filteredCves = globalCves.filter(c => 
      c.cve.toLowerCase().includes(query) ||
      c.title.toLowerCase().includes(query) ||
      c.service.toLowerCase().includes(query) ||
      c.severity.toLowerCase().includes(query)
    );
    renderCveCards(filteredCves);

    // Filter Packets
    const filteredPackets = globalPackets.filter(p =>
      p.id.toLowerCase().includes(query) ||
      p.protocol.toLowerCase().includes(query) ||
      (p.payload_preview && p.payload_preview.toLowerCase().includes(query)) ||
      (p.notes && p.notes.toLowerCase().includes(query))
    );
    renderPcapTable(filteredPackets);
  });

  // 14. Quick Audit Action
  btnQuickAudit.addEventListener('click', () => {
    playSound('scan');
    appendLog('warn', '[AUDIT] Running full laboratory reconnaissance and threat audit...');
    btnRunScan.click();
    runThreatAnalysis();
  });

  // Helper
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // 15. OSINT & API Security Module
  let globalOwasp = [];
  let globalOsintCloud = {};
  const osintPillarsGrid = document.getElementById('osintPillarsGrid');
  const owaspCardsGrid = document.getElementById('owaspCardsGrid');
  const cloudPracticesGrid = document.getElementById('cloudPracticesGrid');
  const btnRunOsintAudit = document.getElementById('btnRunOsintAudit');
  const osintDomainInput = document.getElementById('osintDomainInput');
  const osintAuditLog = document.getElementById('osintAuditLog');

  window.switchOsintSubTab = function(sub) {
    playSound('click');
    document.querySelectorAll('.osint-subview').forEach(v => v.style.display = 'none');
    document.getElementById('btnFilterOsint').classList.remove('active');
    document.getElementById('btnFilterOwasp').classList.remove('active');
    document.getElementById('btnFilterCloud').classList.remove('active');

    if (sub === 'osint') {
      document.getElementById('subViewOsint').style.display = 'block';
      document.getElementById('btnFilterOsint').classList.add('active');
    } else if (sub === 'owasp') {
      document.getElementById('subViewOwasp').style.display = 'block';
      document.getElementById('btnFilterOwasp').classList.add('active');
    } else if (sub === 'cloud') {
      document.getElementById('subViewCloud').style.display = 'block';
      document.getElementById('btnFilterCloud').classList.add('active');
    }
  };

  async function loadOsintAndApiSecurity() {
    try {
      const owaspRes = await fetch('/api/owasp-api');
      globalOwasp = await owaspRes.json();
      renderOwaspCards(globalOwasp);

      const osintRes = await fetch('/api/osint-cloud');
      globalOsintCloud = await osintRes.json();
      if (globalOsintCloud.osint_framework) renderOsintPillars(globalOsintCloud.osint_framework);
      if (globalOsintCloud.cloud_security_best_practices) renderCloudPractices(globalOsintCloud.cloud_security_best_practices);
    } catch (err) {
      console.warn('Failed to load OSINT & API data:', err);
    }
  }

  function renderOsintPillars(pillars) {
    if (!osintPillarsGrid) return;
    osintPillarsGrid.innerHTML = '';
    pillars.forEach(p => {
      const card = document.createElement('div');
      card.className = 'cve-card';
      card.innerHTML = `
        <div>
          <div class="cve-card-top">
            <span class="cve-id">${p.category}</span>
            <span class="badge badge-low">DEFENSIVE OSINT</span>
          </div>
          <h4 class="cve-title">${p.purpose}</h4>
          <div style="font-size: 0.8rem; color: var(--text-secondary); margin: 0.6rem 0;">
            <strong>Authorized Tools & Sources:</strong>
            <ul style="margin: 0.4rem 0 0.8rem 1.2rem; line-height: 1.5;">
              ${p.tools_and_methods.map(t => `<li><code>${t}</code></li>`).join('')}
            </ul>
          </div>
        </div>
        <div class="cve-meta" style="border-left: 2px solid var(--green);">
          <strong style="color: var(--green);">🛡️ Defensive Action:</strong>
          <span>${p.defensive_action}</span>
        </div>
      `;
      osintPillarsGrid.appendChild(card);
    });
  }

  function renderOwaspCards(owaspList) {
    if (!owaspCardsGrid) return;
    owaspCardsGrid.innerHTML = '';
    owaspList.forEach(item => {
      const card = document.createElement('div');
      card.className = 'cve-card';
      const isCrit = item.severity === 'CRITICAL';
      const badgeClass = isCrit ? 'badge-critical' : 'badge-high';

      card.innerHTML = `
        <div>
          <div class="cve-card-top">
            <span class="cve-id" style="color: ${isCrit ? 'var(--red)' : 'var(--cyan)'};">${item.id}</span>
            <span class="badge ${badgeClass}">${item.severity}</span>
          </div>
          <h4 class="cve-title">${item.title}</h4>
          <p class="cve-desc">${item.description}</p>
          <div style="font-size: 0.78rem; color: var(--yellow); margin-bottom: 0.75rem;">
            <strong>Impact:</strong> ${item.impact}
          </div>
        </div>
        <div class="cve-meta" style="border-left: 2px solid var(--green);">
          <strong style="color: var(--green);">Remediation Standard:</strong>
          <span>${item.remediation}</span>
        </div>
      `;
      owaspCardsGrid.appendChild(card);
    });
  }

  function renderCloudPractices(cloudList) {
    if (!cloudPracticesGrid) return;
    cloudPracticesGrid.innerHTML = '';
    cloudList.forEach(item => {
      const card = document.createElement('div');
      card.className = 'cve-card';
      card.innerHTML = `
        <div>
          <div class="cve-card-top">
            <span class="cve-id">${item.pillar}</span>
            <span class="badge badge-low">${item.standard}</span>
          </div>
          <div style="font-size: 0.8rem; color: var(--text-secondary); margin: 0.6rem 0;">
            <ul style="margin: 0.4rem 0 0.8rem 1.2rem; line-height: 1.6;">
              ${item.guidelines.map(g => `<li>${g}</li>`).join('')}
            </ul>
          </div>
        </div>
        <div class="cve-meta" style="border-left: 2px solid var(--cyan);">
          <strong style="color: var(--cyan);">Architecture Rule:</strong>
          <span>Enforce zero-trust least privilege across all service endpoints and credentials.</span>
        </div>
      `;
      cloudPracticesGrid.appendChild(card);
    });
  }

  if (btnRunOsintAudit) {
    btnRunOsintAudit.addEventListener('click', () => {
      const domain = osintDomainInput.value.trim() || 'target-asset.internal';
      playSound('scan');
      osintAuditLog.innerHTML = '';

      const appendOsint = (level, text) => {
        const time = new Date().toTimeString().split(' ')[0];
        const row = document.createElement('div');
        row.className = `log-row ${level}`;
        row.innerHTML = `<span class="log-time">[${time}]</span> ${text}`;
        osintAuditLog.appendChild(row);
      };

      appendOsint('info', `[START] Initiating passive OSINT footprint verification for: ${domain}`);
      setTimeout(() => {
        appendOsint('info', `[DNS] Querying passive DNS records... MX records protected, no wildcards found.`);
      }, 300);
      setTimeout(() => {
        appendOsint('warn', `[CERT] Certificate Transparency (crt.sh): Discovered 3 historical SAN subdomains: api.${domain}, v1-staging.${domain}, mail.${domain}.`);
      }, 700);
      setTimeout(() => {
        appendOsint('alert', `[SECRET SCAN] Checked public repository patterns: No exposed Google API keys or AWS credentials identified for ${domain}.`);
      }, 1100);
      setTimeout(() => {
        appendOsint('info', `[COMPLETED] Passive OSINT assessment complete. Recommendation: Audit and decommission staging endpoint 'v1-staging.${domain}'.`);
        playSound('alert');
      }, 1500);
    });
  }

  // Load Everything
  loadInitialData();
  loadOsintAndApiSecurity();
});
