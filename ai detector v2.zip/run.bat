@echo off
title SentinelLab & AI Threat Detector
echo ========================================================
echo  Starting SentinelLab Security Dashboard...
echo  Opening browser at http://localhost:3000
echo ========================================================
start http://localhost:3000
node server.js
pause
